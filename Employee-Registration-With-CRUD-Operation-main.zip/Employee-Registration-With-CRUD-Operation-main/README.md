# Employee-Registration-With-CRUD-Operation

1) Developed a dynamic web application using Java, HTML, CSS, and Servlets for employee registration
with view, update, and delete functionalities.
2) Integrated JDBC for secure backend database connectivity, ensuring data integrity and accessibility
